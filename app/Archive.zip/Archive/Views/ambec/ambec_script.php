					<!--begin::Main-->
					<div class="app-main flex-column flex-row-fluid" id="kt_app_main">
						<!--begin::Content wrapper-->
						<div class="d-flex flex-column flex-column-fluid">
							<!--begin::Toolbar-->
							<div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
								<!--begin::Toolbar container-->
								<div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
									<!--begin::Page title-->
									<div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
										<!--begin::Title-->
										<h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0"><?php echo $pageTitle;?></h1>
										<!--end::Title-->
										<!--begin::Breadcrumb-->
										<ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
											<!--begin::Item-->
											<li class="breadcrumb-item text-muted">
												<a href="../../demo1/dist/index.html" class="text-muted text-hover-primary">Home</a>
											</li>
											<!--end::Item-->
											<!--begin::Item-->
											<li class="breadcrumb-item">
												<span class="bullet bg-gray-800 w-5px h-2px"></span>
											</li>
											<!--end::Item-->
											<!--begin::Item-->
											<li class="breadcrumb-item text-muted">Pacotes</li>
											<!--end::Item-->
											<!--begin::Item-->
											<li class="breadcrumb-item">
												<span class="bullet bg-gray-800 w-5px h-2px"></span>
											</li>
											<!--end::Item-->
											<!--begin::Item-->
											<li class="breadcrumb-item text-muted">Gerenciar Pacote</li>
											<!--end::Item-->
										</ul>
										<!--end::Breadcrumb-->
									</div>
									<!--end::Page title-->

								</div>
								<!--end::Toolbar container-->
							</div>
							<!--end::Toolbar-->
							<!--begin::Content-->
							<div id="kt_app_content" class="app-content flex-column-fluid">
								
								<!--begin::Content container-->
								<div id="kt_app_content_container" class="app-container container-xxl">
								<div class="row g-5 g-xl-8">
										<div class="col-xl-6">
											<form id="frmDataLake" class="form" action="<?php echo assetfolder;?>pacote-detalhes/<?php echo $pacote['firstRow']->verificador;?>/DEeDeqqew234deT45" method="POST">
												<!-- Inicio: detalhes -->
												<div class="flex-lg-row-fluid">
													<!--begin::Messenger-->
													<div class="card" id="kt_chat_messenger">
														<!--begin::Accordion-->
														<div class="accordion" id="kt_accordion_1  ms-lg-7 ms-xl-10">
															<div class="accordion-item">
																<h2 class="accordion-header" id="kt_accordion_1_header_1">
																	<button class="accordion-button fs-4 fw-semibold" type="button" data-bs-toggle="collapse" data-bs-target="#kt_accordion_1_body_133" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
																		DADOS DO PACOTE
																	</button>
																</h2>
																<div id="kt_accordion_1_body_133" class="accordion-collapse collapse show" aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
																	<div class="accordion-body">
																		<div class="input-group">
																			<span class="input-group-text" style="width: 155px">Usuário</span>
																			<input type="text" class="form-control" placeholder="" name="id_usuario" value="<?php echo $pacote['firstRow']->id_usuario;?>" />
																		</div>
																		<div class="input-group">
																			<span class="input-group-text" style="width: 155px">Título</span>
																			<input type="text" class="form-control" placeholder="" name="titulo" value="<?php echo $pacote['firstRow']->titulo;?>" />
																		</div>
																		<div class="input-group">
																			<span class="input-group-text" style="width: 155px">Descrição curta</span>
																			<input type="text" class="form-control" placeholder="" name="descricao_curta" value="<?php echo $pacote['firstRow']->descricao_curta;?>" />
																		</div>
																		<div class="input-group">
																			<span class="input-group-text" style="width: 155px">Descrição Longa</span>
																			<textarea class="form-control" aria-label="Ocorrências" rows=6 name="descricao_longa"><?php echo $pacote['firstRow']->descricao_longa;?></textarea>
																		</div>
																		<div class="input-group">
																			<span class="input-group-text" style="width: 155px">Preço Normal</span>
																			<input type="text" class="form-control" placeholder="" name="preco_normal" value="<?php echo $pacote['firstRow']->preco_normal;?>" />
																		</div>
																		<div class="input-group">
																			<span class="input-group-text" style="width: 155px">Preço Desconto</span>
																			<input type="text" class="form-control" placeholder="" name="preco_desconto" value="<?php echo $pacote['firstRow']->preco_desconto;?>" />
																		</div>
																		<div class="input-group">
																			<span class="input-group-text" style="width: 155px">Posição Vitrine</span>
																			<input type="text" class="form-control" placeholder="" name="destaque_vitrine" value="<?php echo $pacote['firstRow']->destaque_vitrine;?>" />
																		</div>
																		<div class="input-group">
																			<span class="input-group-text" style="width: 155px">Status</span>
																			<input type="text" class="form-control" placeholder="" name="status_ativo" value="<?php echo $pacote['firstRow']->status_ativo;?>" />
																		</div>
																		<div class="input-group">
																			<span class="input-group-text" style="width: 155px">Lixeira</span>
																			<input type="text" class="form-control" placeholder="" name="pacote_lixeira" value="<?php echo $pacote['firstRow']->pacote_lixeira;?>" />
																		</div>
																		<div class="input-group">
																			<span class="input-group-text bg-color: $ffffff" style="width: 100%"><input class="form-check-input" type="checkbox" name="thumbnail_criada" <?php echo $pacote['firstRow']->thumbnail_criada == TRUE ? "checked" : ""?> value="<?php echo $pacote['firstRow']->thumbnail_criada;?>" />&nbsp;Imagem gerada</span>
																		</div>
																		<div class="d-flex align-items-center position-relative my-1 mt-5 mb-0">
																			<button type="submit" class="btn btn-primary" name="btnSalvar" value="btnSalvar">Salvar pacote</button>										
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<!-- Fim: detalhes -->
											</form>
										</div>
										<div class="col-xl-6">
											<div class="accordion  accordion-toggle-arrow" id="validacaoDados"><div class="card">
												<!--begin::Block-->
												<div class="card-header" id="headingOne4"><div class="card-title" ><i class="flaticon2-checkmark"></i>DADOS DO PACOTE:</div></div>
													<div id="validaContato" class="" data-parent="#validacaoDados"><div class="card-body font-size-h4"><div class="row">
														<div class="form-group col-12  ml-5 mb-0">
															<div>
																<div class="row mt-5"><div class="col-12"><label class="font-size-h3 text-dark fw-bold">Verificador: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo strtoupper($pacote['firstRow']->verificador)?></label></div></div>
																<div class="row"><div class="col-9"><label class="font-size-h3 fw-bold text-dark">Título: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->titulo?></label></div></div>
																<div class="row"><div class="col-9"><label class="font-size-h3 fw-bold text-dark">Descrição: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->descricao_curta;?></label></div></div>
																<div class="row"><div class="col-12"><label class="font-size-h3 fw-bold text-dark">Data criação: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo str_replace("-", "/", dataUsPt($pacote['firstRow']->data_criacao))?></label></div></div>
																<div class="row"><div class="col-12"><label class="font-size-h3 fw-bold text-dark">Data Update: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo str_replace("-", "/", dataUsPt($pacote['firstRow']->last_update))?></label></div></div>
															</div>
														</div>
													</div></div></div>
												<!--end::Block-->
												<!--begin::Block-->
												<div class="card-header" id="headingOne4"><div class="card-title" ><i class="flaticon2-checkmark"></i>INDICADORES:</div></div>
													<div id="validaContato" class="" data-parent="#validacaoDados"><div class="card-body font-size-h4"><div class="row">
														<div class="form-group col-12  ml-5 mb-0">
															<div>
																<div class="row mt-5"><div class="col-12"><label class="font-size-h3 text-dark fw-bold">Likes: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->stars?></label></div></div>
																<div class="row"><div class="col-9"><label class="font-size-h3 fw-bold text-dark">Compras: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->installs?></label></div></div>
																<div class="row"><div class="col-9"><label class="font-size-h3 fw-bold text-dark">Prompts: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->prompt_count;?></label></div></div>
																<div class="row"><div class="col-9"><label class="font-size-h3 fw-bold text-dark">Tokens: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->prompt_tokens;?></label></div></div>
																<div class="row"><div class="col-9"><label class="font-size-h3 fw-bold text-dark">Gera texto: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->prompt_gpt;?></label></div></div>
																<div class="row"><div class="col-9"><label class="font-size-h3 fw-bold text-dark">Gera Imagem: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->prompt_image;?></label></div></div>
																<div class="row"><div class="col-9"><label class="font-size-h3 fw-bold text-dark">Gera Áudio: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->prompt_audio;?></label></div></div>
																<div class="row"><div class="col-9"><label class="font-size-h3 fw-bold text-dark">Gera Vídeo: </label> <label class="font-size-h3 font-weight-light text-dark"><?php echo $pacote['firstRow']->prompt_video;?></label></div></div>
															</div>
														</div>
													</div></div></div>
												<!--end::Block-->
											</div></div>
											
										</div>
									</div>
									
								</div>
								<!--end::Content container-->
							</div>
							<!--end::Content-->
						</div>
						<!--end::Content wrapper-->
						<!--begin::Footer-->
						<div id="kt_app_footer" class="app-footer">
							<!--begin::Footer container-->
							<div class="app-container container-fluid d-flex flex-column flex-md-row flex-center flex-md-stack py-3">
								<!--begin::Copyright-->
								<div class="text-dark order-2 order-md-1">
									<span class="text-muted fw-semibold me-1">2023&copy;</span>
									<a href="https://keenthemes.com" target="_blank" class="text-gray-800 text-hover-primary">Keenthemes</a>
								</div>
								<!--end::Copyright-->
								<!--begin::Menu-->
								<ul class="menu menu-gray-600 menu-hover-primary fw-semibold order-1">
									<li class="menu-item">
										<a href="https://keenthemes.com" target="_blank" class="menu-link px-2">About</a>
									</li>
									<li class="menu-item">
										<a href="https://devs.keenthemes.com" target="_blank" class="menu-link px-2">Support</a>
									</li>
									<li class="menu-item">
										<a href="https://1.envato.market/EA4JP" target="_blank" class="menu-link px-2">Purchase</a>
									</li>
								</ul>
								<!--end::Menu-->
							</div>
							<!--end::Footer container-->
						</div>
						<!--end::Footer-->
					</div>
					<!--end:::Main-->