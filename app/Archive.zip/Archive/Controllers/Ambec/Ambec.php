<?php

namespace App\Controllers\Ambec;
use App\Controllers\BaseController;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Libraries\dbMaster;

class Ambec extends BaseController
{
    protected $session;
    protected $dbMasterDefault;

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger) {
        parent::setDB("fgtsDB"); //passa o banco de dados diferente do default (opcional) antes de iniciar o controler
        parent::initController($request, $response, $logger);
        $this->checkSession();

        //nesse caso o dbMaster vai apontar para o banco FGTS

        //o dbMasterDefault vai apontar para o banco do InsightSuite
        $this->dbMasterDefault = new dbMaster();
        $this->session = session();
    }

   //http://localhost/mercadogpt/ambec/script
	public function ambec_script(){
		
		$data['PageTitle'] = "Criar script AMBEC";

		$nome = $this->core->getpost('nome');
		$operador = $this->core->getpost('operador');
		$nascimento = $this->core->getpost('nascimento');
		$cpf = $this->core->getpost('cpf');
		$hora = $this->core->getpost('hora');
		$telefone = $this->core->getpost('telefone');
		$sexo = $this->core->getpost('sexo');
		$gerado = false;
		$audio1 = '';
		$audio2 = '';
		$audio3 = '';
		$audio4 = '';
		$prefix = '';
		$operador_prefix = '';

		$eleven = array("model_id" => "eleven_multilingual_v1" ,  "voice_settings" => array("stability" => 0.43, "similarity_boost" => 0.75));

		$script = [];

		if (!empty($nome)){
			$dia = $this->dataPorExtenso($nascimento)['dia'];
			$mes = $this->dataPorExtenso($nascimento)['mes'];
			$operador_prefix = textToSlug($operador);
			$nome_prefix = textToSlug($nome);
			$prefix = $operador_prefix . "_" . $nome_prefix;

			$gerado = true;

			//NASCIMENTO
			$dia = $this->dataPorExtenso($nascimento)['dia'];
			$mes = $this->dataPorExtenso($nascimento)['mes'];
			$cpf_resto = substr(limparMascara($cpf), -8);

			
			$script[] = [$prefix . '_audio1.mp3', "$sexo $nome, $hora. Meu nome é $operador "];
			$script[] = [$operador_prefix . '_audio2.mp3', " sou da área de qualidade responsável por validar a sua filiação a ambék. Para sua segurança, esse contato será gravado "];
			$script[] = [$operador_prefix . '_audio3.mp3', "Para concluirmos a sua filiação a ambék, farei a confirmação de algumas informações do seu cadastro. Por favor, qual seu nome completo?"];
			$script[] = [$prefix . '_audio4a.mp3', "Agora complemente sua data de nascimento "];
			$script[] = [$prefix . '_audio4b.mp3', " você nasceu no dia $dia do mês de $mes de qual ano?"];
			$script[] = [$operador_prefix . '_audio5.mp3', "Por gentileza, informe os três primeiros números do seu CPF?"];
			$script[] = [$prefix . '_audio6.mp3', "Certo. Com final " . $this->numerosPorExtenso($cpf_resto) . "."];
			$script[] = [$operador_prefix . '_audio7.mp3', "Você autoriza o uso das informações confirmadas para cadastro no clube de benefícios e o compartilhamento com empresas parceiras da ambék, conforme nossa política de dados disponível no site ambék?"];
			$script[] = [$operador_prefix . '_audio8.mp3', "Agora farei a leitura do termo de seu consentimento e peço a gentileza que ao final confirme se estiver de acordo:"];
			$script[] = [$operador_prefix . '_audio9.mp3', "Você autoriza o desconto mensal de quarenta e cinco reais do seu benefício previdenciário em favor da ambék e está ciente que a utilização de seus benefícios está condicionada ao desconto mensal deste valor?"];
			$script[] = [$operador_prefix . '_audio10.mp3', "Agradeço sua confirmação e peço que confirme se recebeu agora um S M S em seu telefone "];
			$script[] = [$prefix . '_audio11.mp3', " o final do seu celular é " . $this->numerosPorExtenso(substr($telefone, -4))];
			$script[] = [$operador_prefix . '_audio12.mp3', "Por favor, clique no endereço recebido pelo SMS e confirme também a filiação por este canal para sua maior segurança."];
			$script[] = [$operador_prefix . '_audio13.mp3', "Muito obrigado, e parabéns por sua filiação a ambék! Em breve você receberá nosso kit de boas-vindas com todas as vantagens e como utilizá-las. Seja bem-vindo a ambék!"];

			foreach ($script as $key => $value){
				$file = $script[$key][0];
				$text = $script[$key][1];

				if (!file_exists((PATH_SAVE_AMBEC . $file))){
					$body = json_encode(array("text" => $text) + $eleven);
					$result = $this->m_elevenLabs->textToSpeech($body);
		
					if ($result['sucesso']){
						file_put_contents(PATH_SAVE_AMBEC . $file, $result['retorno']);
					}
				}
			}
		}

		$data['script'] = $script;

		$data['gerado'] = $gerado;
		$data['nome'] = $nome;
		$data['cpf'] = $cpf;
		$data['operador'] = $operador;
		$data['nascimento'] = $nascimento;
		$data['cpf'] = $cpf;
		$data['telefone'] = $telefone;
		$data['hora'] = $hora;
		$data['sexo'] = $sexo;
		$data['here'] = 'creator';
        return $this->loadpage('ambec/ambec_script', $data);
	}


	function numerosPorExtenso($numero) {
		// Array com os algarismos por extenso
		$algarismosPorExtenso = array(
			'0' => 'zero',
			'1' => 'um',
			'2' => 'dois',
			'3' => 'três',
			'4' => 'quatro',
			'5' => 'cinco',
			'6' => 'meia',
			'7' => 'sete',
			'8' => 'oito',
			'9' => 'nove',
		);
	
		$resultado = '';
	
		// Converte o número para uma string para iterar cada algarismo
		$numeroString = (string) $numero;
	
		// Itera cada algarismo e adiciona sua forma por extenso ao resultado
		for ($i = 0; $i < strlen($numeroString); $i++) {
			$algarismo = $numeroString[$i];
			$resultado .= $algarismosPorExtenso[$algarismo] . ' ';
		}
	
		return rtrim($resultado); // Remove o espaço extra no final
	}
	
	function dataPorExtenso($data) {
		// Dividir a data em dia, mês e ano
		list($dia, $mes, $ano) = explode('/', $data);
	
		// Array com os dias por extenso
		$diasPorExtenso = array(
			'01' => 'um',
			'02' => 'dois',
			'03' => 'três',
			'04' => 'quatro',
			'05' => 'cinco',
			'06' => 'seis',
			'07' => 'sete',
			'08' => 'oito',
			'09' => 'nove',
			'10' => 'dez',
			'11' => 'onze',
			'12' => 'doze',
			'13' => 'treze',
			'14' => 'quatorze',
			'15' => 'quinze',
			'16' => 'dezesseis',
			'17' => 'dezessete',
			'18' => 'dezoito',
			'19' => 'dezenove',
			'20' => 'vinte',
			'21' => 'vinte e um',
			'22' => 'vinte e dois',
			'23' => 'vinte e três',
			'24' => 'vinte e quatro',
			'25' => 'vinte e cinco',
			'26' => 'vinte e seis',
			'27' => 'vinte e sete',
			'28' => 'vinte e oito',
			'29' => 'vinte e nove',
			'30' => 'trinta',
			'31' => 'trinta e um',
		);
	
		// Array com os meses por extenso
		$mesesPorExtenso = array(
			'01' => 'janeiro',
			'02' => 'fevereiro',
			'03' => 'março',
			'04' => 'abril',
			'05' => 'maio',
			'06' => 'junho',
			'07' => 'julho',
			'08' => 'agosto',
			'09' => 'setembro',
			'10' => 'outubro',
			'11' => 'novembro',
			'12' => 'dezembro',
		);
	
		// Retorna a data por extenso
		return ['dia' => $diasPorExtenso[$dia], 'mes' => $mesesPorExtenso[$mes]];
	} 

}
