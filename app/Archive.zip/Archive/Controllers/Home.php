<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $dados['pageTitle'] = "Simplificando sua vida financeira";
        echo "11:17:39 - Breakpoint 6"; exit;					//<-------DEBUG
        return $this->loadpage('headers/home-default', $dados);
    }

}
